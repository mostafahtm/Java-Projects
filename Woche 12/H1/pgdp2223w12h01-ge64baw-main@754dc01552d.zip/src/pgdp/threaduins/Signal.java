package pgdp.threaduins;

public interface Signal {

	void await();

}
