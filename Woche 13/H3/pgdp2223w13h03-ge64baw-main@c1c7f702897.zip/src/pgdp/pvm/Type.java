package pgdp.pvm;

public enum Type {
    BOOL, INT, UNDEFINED
}
